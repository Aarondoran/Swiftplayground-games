import SwiftUI

struct BallShop: View {
    @Binding var coins: Int
    @Binding var selectedBallIndex: Int
    @Binding var isShowingShop: Bool
    
    @State private var unlockedBalls: [Bool] = UserDefaults.standard.array(forKey: "unlockedBalls") as? [Bool] ?? [true, false, false, false, false]
    
    private let ballColors: [Color] = [.gray, .red, .blue, .green, .yellow]
    private let ballPrices: [Int] = [0, 50, 75, 100, 150]
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Ball Shop")
                .font(.largeTitle)
                .foregroundColor(.white)
            
            Text("Coins: \(coins)")
                .font(.title2)
                .foregroundColor(.yellow)
            
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 20) {
                ForEach(0..<ballColors.count, id: \.self) { index in
                    VStack {
                        Circle()
                            .fill(ballColors[index])
                            .frame(width: 50, height: 50)
                            .overlay(Circle().stroke(selectedBallIndex == index ? Color.white : Color.clear, lineWidth: 3))
                            .onTapGesture {
                                if unlockedBalls[index] {
                                    selectedBallIndex = index
                                    saveSelection()
                                } else if coins >= ballPrices[index] {
                                    coins -= ballPrices[index]
                                    unlockedBalls[index] = true
                                    selectedBallIndex = index
                                    saveSelection()
                                    UserDefaults.standard.set(coins, forKey: "coins")
                                }
                            }
                        
                        Text(unlockedBalls[index] ? "Owned" : "\(ballPrices[index])")
                            .foregroundColor(.white)
                            .font(.caption)
                    }
                }
            }
            
            Button("Close") { isShowingShop = false }
                .font(.title2)
                .foregroundColor(.white)
                .padding()
                .background(Color.blue)
                .cornerRadius(15)
            
            Spacer()
        }
        .padding(.top, 30)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.ignoresSafeArea())
    }
    
    private func saveSelection() {
        UserDefaults.standard.set(selectedBallIndex, forKey: "selectedBallIndex")
        UserDefaults.standard.set(unlockedBalls, forKey: "unlockedBalls")
    }
}
