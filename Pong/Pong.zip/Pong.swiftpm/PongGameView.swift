import SwiftUI

struct PongGameView: View {
    @Binding var isPlaying: Bool
    @Binding var coins: Int
    
    var ballSpeed: CGFloat
    var paddleHeight: CGFloat
    var aiSpeed: CGFloat
    var bgColor: Color
    var ballIndex: Int
    
    private let ballSize: CGFloat = 20
    private let paddleWidth: CGFloat = 20
    private let winningScore = 5
    private let timer = Timer.publish(every: 1/60, on: .main, in: .common).autoconnect()
    
    @State private var leftPaddleY: CGFloat = 0
    @State private var rightPaddleY: CGFloat = 0
    @State private var ball = CGPoint(x: 0, y: 0)
    @State private var ballVelocity = CGVector(dx: 0, dy: 0)
    @State private var leftScore = 0
    @State private var rightScore = 0
    @State private var showWinMessage = false
    @State private var won = false
    @State private var isPaused = false
    
    private let ballColors: [Color] = [.gray, .red, .blue, .green, .yellow]
    
    var body: some View {
        GeometryReader { geo in
            let courtWidth = geo.size.width
            let courtHeight = geo.size.height
            
            ZStack {
                bgColor.ignoresSafeArea()
                
                // Scores
                VStack {
                    HStack {
                        Text("\(leftScore)")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 30)
                        Text("\(rightScore)")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .padding(.trailing, 30)
                    }
                    .padding(.top, 20)
                    Spacer()
                }
                
                // Paddles
                Rectangle()
                    .fill(Color.white)
                    .frame(width: paddleWidth, height: paddleHeight)
                    .position(x: 30, y: leftPaddleY == 0 ? courtHeight/2 : leftPaddleY)
                
                Rectangle()
                    .fill(Color.white)
                    .frame(width: paddleWidth, height: paddleHeight)
                    .position(x: courtWidth - 30, y: rightPaddleY == 0 ? courtHeight/2 : rightPaddleY)
                
                // Ball
                Circle()
                    .fill(ballColors[safe: ballIndex] ?? .gray)
                    .frame(width: ballSize, height: ballSize)
                    .position(x: ball.x == 0 ? courtWidth/2 : ball.x,
                              y: ball.y == 0 ? courtHeight/2 : ball.y)
                
                // Exit & Pause Buttons
                VStack {
                    HStack {
                        Button("Exit") { isPlaying = false }
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.red.opacity(0.7))
                            .cornerRadius(10)
                        
                        Spacer()
                        
                        Button(isPaused ? "Resume" : "Pause") { isPaused.toggle() }
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue.opacity(0.7))
                            .cornerRadius(10)
                    }
                    Spacer()
                }
                .padding()
                
                // Win Message Overlay
                if showWinMessage {
                    VStack(spacing: 20) {
                        Text(won ? "You Win!" : "You Lose!")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                        Text("Coins: \(coins)")
                            .foregroundColor(.yellow)
                        Button("Play Again") {
                            leftScore = 0
                            rightScore = 0
                            resetBall(courtWidth: courtWidth, courtHeight: courtHeight)
                            showWinMessage = false
                        }
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                        Button("Exit") { isPlaying = false }
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.gray)
                            .cornerRadius(10)
                    }
                    .padding()
                    .background(Color.black.opacity(0.8))
                    .cornerRadius(15)
                }
            }
            .gesture(DragGesture(minimumDistance: 0).onChanged { value in
                if value.location.x < courtWidth / 2 {
                    leftPaddleY = clamp(value.location.y, min: paddleHeight/2, max: courtHeight - paddleHeight/2)
                }
            })
            .onReceive(timer) { _ in
                guard !showWinMessage, !isPaused else { return }
                updateBall(courtWidth: courtWidth, courtHeight: courtHeight)
                updateAI(courtHeight: courtHeight)
            }
            .onAppear {
                leftPaddleY = courtHeight / 2
                rightPaddleY = courtHeight / 2
                resetBall(courtWidth: courtWidth, courtHeight: courtHeight)
            }
        }
    }
    
    private func clamp(_ value: CGFloat, min: CGFloat, max: CGFloat) -> CGFloat {
        Swift.min(Swift.max(value, min), max)
    }
    
    private func updateBall(courtWidth: CGFloat, courtHeight: CGFloat) {
        ball.x += ballVelocity.dx
        ball.y += ballVelocity.dy
        
        if ball.y <= ballSize/2 || ball.y >= courtHeight - ballSize/2 {
            ballVelocity.dy *= -1
        }
        
        let leftPaddleX: CGFloat = 30
        let rightPaddleX: CGFloat = courtWidth - 30
        
        if checkCollision(paddleX: leftPaddleX, paddleY: leftPaddleY) && ballVelocity.dx < 0 {
            ball.x = leftPaddleX + paddleWidth/2 + ballSize/2
            ballVelocity.dx = abs(ballVelocity.dx)
            applyPaddleHitEffect(paddleY: leftPaddleY)
        }
        
        if checkCollision(paddleX: rightPaddleX, paddleY: rightPaddleY) && ballVelocity.dx > 0 {
            ball.x = rightPaddleX - paddleWidth/2 - ballSize/2
            ballVelocity.dx = -abs(ballVelocity.dx)
            applyPaddleHitEffect(paddleY: rightPaddleY)
        }
        
        if ball.x < 0 {
            rightScore += 1
            checkWin()
            resetBall(courtWidth: courtWidth, courtHeight: courtHeight)
        } else if ball.x > courtWidth {
            leftScore += 1
            checkWin()
            resetBall(courtWidth: courtWidth, courtHeight: courtHeight)
        }
    }
    
    private func checkWin() {
        if leftScore >= winningScore {
            won = true
            coins += Int(ballSpeed + aiSpeed) * 2
            UserDefaults.standard.set(coins, forKey: "coins")
            showWinMessage = true
        } else if rightScore >= winningScore {
            won = false
            showWinMessage = true
        }
    }
    
    private func checkCollision(paddleX: CGFloat, paddleY: CGFloat) -> Bool {
        let paddleRect = CGRect(x: paddleX - paddleWidth/2 - ballSize/2,
                                y: paddleY - paddleHeight/2 - ballSize/2,
                                width: paddleWidth + ballSize,
                                height: paddleHeight + ballSize)
        let ballRect = CGRect(x: ball.x - ballSize/2, y: ball.y - ballSize/2, width: ballSize, height: ballSize)
        return paddleRect.intersects(ballRect)
    }
    
    private func applyPaddleHitEffect(paddleY: CGFloat) {
        let offset = (ball.y - paddleY)/(paddleHeight/2)
        ballVelocity.dy += offset * 6
        let maxSpeed: CGFloat = 12
        ballVelocity.dx = (ballVelocity.dx >= 0 ? 1 : -1) * min(abs(ballVelocity.dx)*1.03, maxSpeed)
        ballVelocity.dy = max(min(ballVelocity.dy, maxSpeed), -maxSpeed)
    }
    
    private func resetBall(courtWidth: CGFloat, courtHeight: CGFloat) {
        ball = CGPoint(x: courtWidth/2, y: courtHeight/2)
        ballVelocity = CGVector(dx: Bool.random() ? ballSpeed : -ballSpeed,
                                dy: Bool.random() ? ballSpeed/1.5 : -ballSpeed/1.5)
    }
    
    private func updateAI(courtHeight: CGFloat) {
        if ball.y > rightPaddleY + 10 {
            rightPaddleY = min(rightPaddleY + aiSpeed, courtHeight - paddleHeight/2)
        } else if ball.y < rightPaddleY - 10 {
            rightPaddleY = max(rightPaddleY - aiSpeed, paddleHeight/2)
        }
    }
}

// Safe array indexing
extension Collection {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
