import SwiftUI

enum Difficulty: String {
    case easy, medium, hard
    
    var ballSpeed: CGFloat {
        switch self {
        case .easy: return 4
        case .medium: return 6
        case .hard: return 8
        }
    }
    
    var aiSpeed: CGFloat {
        switch self {
        case .easy: return 2
        case .medium: return 4
        case .hard: return 6
        }
    }
}

struct ContentView: View {
    @State private var isPlaying = false
    @State private var selectedDifficulty: Difficulty = .easy
    @State private var coins: Int = UserDefaults.standard.integer(forKey: "coins")
    @State private var selectedBallIndex: Int = {
        let stored = UserDefaults.standard.integer(forKey: "selectedBallIndex")
        return stored >= 0 && stored < 5 ? stored : 0
    }()
    @State private var isShowingShop: Bool = false
    
    var body: some View {
        if isPlaying {
            PongGameView(
                isPlaying: $isPlaying,
                coins: $coins,
                ballSpeed: selectedDifficulty.ballSpeed,
                paddleHeight: 120,
                aiSpeed: selectedDifficulty.aiSpeed,
                bgColor: Color.black,
                ballIndex: selectedBallIndex
            )
        } else if isShowingShop {
            BallShop(
                coins: $coins,
                selectedBallIndex: $selectedBallIndex,
                isShowingShop: $isShowingShop
            )
        } else {
            HomeView(
                isPlaying: $isPlaying,
                selectedDifficulty: $selectedDifficulty,
                coins: $coins,
                isShowingShop: $isShowingShop
            )
        }
    }
}

struct HomeView: View {
    @Binding var isPlaying: Bool
    @Binding var selectedDifficulty: Difficulty
    @Binding var coins: Int
    @Binding var isShowingShop: Bool
    
    var body: some View {
        VStack(spacing: 40) {
            Text("PONG")
                .font(.system(size: 60, weight: .bold))
                .foregroundColor(.white)
            
            Text("Coins: \(coins)")
                .font(.title2)
                .foregroundColor(.yellow)
            
            VStack(spacing: 20) {
                Text("Select Difficulty")
                    .foregroundColor(.white)
                HStack(spacing: 20) {
                    Button("Easy") { selectedDifficulty = .easy }
                        .padding()
                        .background(selectedDifficulty == .easy ? Color.green : Color.gray)
                        .cornerRadius(10)
                    
                    Button("Medium") { selectedDifficulty = .medium }
                        .padding()
                        .background(selectedDifficulty == .medium ? Color.orange : Color.gray)
                        .cornerRadius(10)
                    
                    Button("Hard") { selectedDifficulty = .hard }
                        .padding()
                        .background(selectedDifficulty == .hard ? Color.red : Color.gray)
                        .cornerRadius(10)
                }
            }
            
            Button(action: { isPlaying = true }) {
                Text("Play")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding()
                    .frame(width: 200)
                    .background(Color.blue)
                    .cornerRadius(15)
            }
            
            Button(action: { isShowingShop = true }) {
                Text("Ball Shop")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .frame(width: 200)
                    .background(Color.purple)
                    .cornerRadius(15)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.ignoresSafeArea())
    }
}
