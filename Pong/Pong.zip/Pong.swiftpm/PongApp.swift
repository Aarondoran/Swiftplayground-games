import SwiftUI

@main
struct PongApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
