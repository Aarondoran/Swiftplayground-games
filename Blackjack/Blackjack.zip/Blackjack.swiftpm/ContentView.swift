import SwiftUI

struct ContentView: View {
    @State var isPlaying = false
    @State var showInstructions = false
    @State var showResetConfirm = false
    @State var coins: Int = {
        let stored = UserDefaults.standard.integer(forKey: "bj_coins")
        return stored > 0 ? stored : 100
    }()
    
    var body: some View {
        if isPlaying {
            BlackjackGameView(isPlaying: $isPlaying, coins: $coins)
        } else {
            VStack(spacing: 30) {
                Spacer()
                
                Text("BLACKJACK")
                    .font(.system(size: 48, weight: .bold))
                    .foregroundColor(.white)
                
                Text("Coins: \(coins)")
                    .font(.title2)
                    .foregroundColor(.yellow)
                
                // Play button (fully tappable)
                Button(action: {
                    isPlaying = true
                    if coins == 0 {
                        coins = 100
                        UserDefaults.standard.set(coins, forKey: "bj_coins")
                    }
                }) {
                    Text("Play")
                        .font(.title2)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 50)
                        .background(Color.blue)
                        .cornerRadius(12)
                        .padding(.horizontal, 40)
                        .shadow(radius: 4)
                }
                
                // Instructions button
                Button(action: {
                    showInstructions = true
                }) {
                    Text("Instructions")
                        .font(.title3)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 50)
                        .background(Color.orange)
                        .cornerRadius(12)
                        .padding(.horizontal, 40)
                        .shadow(radius: 4)
                }
                .sheet(isPresented: $showInstructions) {
                    InstructionsView()
                }
                
                // "I'm bankrupt" button
                Button(action: {
                    showResetConfirm = true
                }) {
                    Text("I'm bankrupt")
                        .font(.footnote)
                        .foregroundColor(.white)
                        .padding(.vertical, 6)
                }
                .alert("Are you sure you want to reset your coins to 10?", isPresented: $showResetConfirm) {
                    Button("Yes, reset to 10") {
                        coins = 10
                        UserDefaults.standard.set(coins, forKey: "bj_coins")
                    }
                    Button("Cancel", role: .cancel) { }
                }
                
                
                .padding(.top, 60)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black.ignoresSafeArea())
                .onAppear {
                    UserDefaults.standard.set(coins, forKey: "bj_coins")
                }
            }
        }
    }
    
    // Instructions Modal
    struct InstructionsView: View {
        @Environment(\.dismiss) var dismiss
        
        var body: some View {
            NavigationView {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Blackjack Instructions")
                            .font(.title2)
                            .bold()
                        
                        Text("""
1. Each game is played against the dealer.
2. Start by selecting your bet using the chips.
3. Press 'Deal' to receive your cards.
4. Your goal is to get closer to 21 than the dealer without going over.
5. Press 'Hit' to draw another card.
6. Press 'Stand' to end your turn.
7. If your hand exceeds 21, you bust and lose the bet.
8. Dealer must draw until their hand is 17 or higher.
9. Winning returns double your bet, tie returns the bet.
10. Coins automatically top up to 100 if you reach 0.
""")
                    }
                    .padding()
                }
                .navigationTitle("Instructions")
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Close") { dismiss() }
                    }
                }
            }
        }
    }
}
