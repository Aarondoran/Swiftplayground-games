import SwiftUI

struct Card: Identifiable, Equatable {
    let id = UUID()
    let rank: String
    let suit: String
    
    var value: Int {
        switch rank {
        case "A": return 11
        case "K","Q","J": return 10
        default: return Int(rank) ?? 0
        }
    }
    
    static func == (lhs: Card, rhs: Card) -> Bool {
        lhs.id == rhs.id
    }
}

struct BlackjackGameView: View {
    @Binding var isPlaying: Bool
    @Binding var coins: Int
    
    @State private var deck: [Card] = []
    @State private var playerHand: [Card] = []
    @State private var dealerHand: [Card] = []
    @State private var bet: Int = 0
    @State private var roundOver: Bool = true
    @State private var playerStand: Bool = false
    @State private var message: String = "Select your bet and press Deal"
    @State private var showExitConfirm: Bool = false
    
    private let minBet = 10
    private let chipValues = [10, 50, 100, 500]
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                VStack {
                    // Top controls
                    HStack {
                        Button("Exit") { showExitConfirm = true }
                            .padding(8)
                            .background(Color.red.opacity(0.8))
                            .foregroundColor(.white)
                            .cornerRadius(8)
                        Spacer()
                        Text("Coins: \(coins)")
                            .foregroundColor(.yellow)
                    }
                    .padding()
                    
                    Spacer()
                    
                    // Dealer hand
                    VStack(spacing: 10) {
                        Text("Dealer")
                            .foregroundColor(.white)
                        HStack(spacing: 12) {
                            ForEach(Array(dealerHand.enumerated()), id: \.element.id) { index, card in
                                let facedown = index == dealerHand.count - 1 && shouldHideDealerCard
                                cardView(card: card, facedown: facedown)
                                    .transition(.move(edge: .trailing).combined(with: .opacity))
                                    .animation(.easeOut(duration: 0.4), value: dealerHand)
                            }
                        }
                    }
                    .padding(.bottom, 24)
                    
                    // Player hand
                    VStack(spacing: 10) {
                        Text("You")
                            .foregroundColor(.white)
                        HStack(spacing: 12) {
                            ForEach(playerHand) { card in
                                cardView(card: card, facedown: false)
                                    .transition(.move(edge: .leading).combined(with: .opacity))
                                    .animation(.easeOut(duration: 0.4), value: playerHand)
                            }
                        }
                    }
                    .padding(.bottom, 24)
                    
                    // Betting chips + Reset Bet button
                    if roundOver {
                        VStack(spacing: 8) {
                            Text("Bet: \(bet)")
                                .foregroundColor(.white)
                                .font(.headline)
                            
                            HStack(spacing: 16) {
                                ForEach(chipValues, id: \.self) { value in
                                    Button(action: {
                                        if bet + value <= coins { bet += value }
                                    }) {
                                        ZStack {
                                            Circle()
                                                .fill(chipColor(for: value))
                                                .frame(width: 50, height: 50)
                                                .shadow(radius: 3)
                                            Text("\(value)")
                                                .foregroundColor(.white)
                                                .font(.subheadline)
                                                .bold()
                                        }
                                    }
                                    .disabled(bet + value > coins)
                                    .opacity(bet + value > coins ? 0.4 : 1.0)
                                }
                                // Reset Bet button
                                Button(action: { bet = 0 }) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color.gray)
                                            .frame(width: 50, height: 50)
                                            .shadow(radius: 3)
                                        Text("R")
                                            .foregroundColor(.white)
                                            .bold()
                                    }
                                }
                            }
                        }
                        .padding(.bottom, 16)
                    }
                    
                    // Message
                    Text(message)
                        .foregroundColor(.white)
                        .font(.headline)
                        .padding(.bottom, 12)
                    
                    // Controls
                    HStack(spacing: 12) {
                        Button("Hit") { playerHit() }
                            .disabled(roundOver || playerStand)
                            .buttonStyle(GameButtonStyle(bg: Color.green))
                        Button("Stand") { playerStandAction() }
                            .disabled(roundOver || playerStand)
                            .buttonStyle(GameButtonStyle(bg: Color.orange))
                        if roundOver {
                            Button(action: { startRound() }) {
                                Text("Deal")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                            .frame(maxWidth: 120)
                        }
                    }
                    .padding(.bottom, 30)
                    
                    Spacer()
                }
                
                if showExitConfirm {
                    Color.black.opacity(0.6).ignoresSafeArea()
                    VStack(spacing: 16) {
                        Text("Exit to Home?")
                            .font(.title2)
                            .foregroundColor(.white)
                        HStack {
                            Button("Cancel") { showExitConfirm = false }
                                .padding().background(Color.gray).cornerRadius(8).foregroundColor(.white)
                            Button("Exit") { isPlaying = false }
                                .padding().background(Color.red).cornerRadius(8).foregroundColor(.white)
                        }
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                }
            }
            .onAppear {
                if coins <= 0 { coins = 100; UserDefaults.standard.set(coins, forKey: "bj_coins") }
                prepareDeck()
            }
        }
    }
    
    // MARK: UI helpers
    private var shouldHideDealerCard: Bool {
        return !playerStand && !roundOver && dealerHand.count > 0
    }
    
    private func cardView(card: Card, facedown: Bool) -> some View {
        ZStack {
            if facedown {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray)
                    .frame(width: 56, height: 80)
                    .shadow(radius: 3)
            } else {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white)
                    .frame(width: 56, height: 80)
                    .shadow(radius: 3)
                    .overlay(
                        VStack {
                            Text(card.rank).font(.headline).foregroundColor(cardSuitColor(card.suit))
                            Text(card.suit).font(.title2).foregroundColor(cardSuitColor(card.suit))
                        }
                    )
            }
        }
    }
    
    private func cardSuitColor(_ suit: String) -> Color {
        return (suit == "♥︎" || suit == "♦︎") ? .red : .black
    }
    
    private func chipColor(for value: Int) -> Color {
        switch value {
        case 10: return .blue
        case 50: return .green
        case 100: return .red
        case 500: return .purple
        default: return .gray
        }
    }
    
    // MARK: Game logic
    private func prepareDeck() {
        deck = []
        let suits = ["♠︎","♥︎","♦︎","♣︎"]
        for s in suits {
            for i in 2...10 { deck.append(Card(rank: "\(i)", suit: s)) }
            deck.append(Card(rank: "J", suit: s))
            deck.append(Card(rank: "Q", suit: s))
            deck.append(Card(rank: "K", suit: s))
            deck.append(Card(rank: "A", suit: s))
        }
        deck.shuffle()
    }
    
    private func drawCard() -> Card {
        if deck.isEmpty { prepareDeck() }
        return deck.removeFirst()
    }
    
    private func handValue(_ hand: [Card]) -> Int {
        var total = hand.reduce(0) { $0 + $1.value }
        var aces = hand.filter { $0.rank == "A" }.count
        while total > 21 && aces > 0 {
            total -= 10
            aces -= 1
        }
        return total
    }
    
    private func startRound() {
        guard bet >= minBet else { message = "Select at least \(minBet) coins to bet"; return }
        if coins <= 0 { coins = 100 }
        coins = max(coins, 0)
        if bet > coins { bet = coins }
        coins -= bet
        UserDefaults.standard.set(coins, forKey: "bj_coins")
        
        playerHand = []
        dealerHand = []
        playerStand = false
        roundOver = false
        message = "Hit or Stand"
        
        if deck.count < 10 { prepareDeck() }
        
        withAnimation {
            playerHand.append(drawCard())
            playerHand.append(drawCard())
            dealerHand.append(drawCard())
            dealerHand.append(drawCard())
        }
        
        if handValue(playerHand) == 21 {
            finishRound()
        }
    }
    
    private func playerHit() {
        guard !roundOver && !playerStand else { return }
        withAnimation { playerHand.append(drawCard()) }
        if handValue(playerHand) > 21 { finishRound() }
    }
    
    private func playerStandAction() {
        guard !roundOver else { return }
        playerStand = true
        finishRound()
    }
    
    private func finishRound() {
        while handValue(dealerHand) < 17 { withAnimation { dealerHand.append(drawCard()) } }
        let pVal = handValue(playerHand)
        let dVal = handValue(dealerHand)
        
        if pVal > 21 {
            message = "You busted!"
        } else if dVal > 21 {
            coins += bet*2
            message = "Dealer busted! You win \(bet*2) coins."
        } else if pVal > dVal {
            coins += bet*2
            message = "You beat the dealer! You win \(bet*2) coins."
        } else if pVal == dVal {
            coins += bet
            message = "Push. Bet returned."
        } else {
            message = "Dealer wins."
        }
        roundOver = true
        UserDefaults.standard.set(coins, forKey: "bj_coins")
        bet = 0
    }
}

// MARK: Button Style
struct GameButtonStyle: ButtonStyle {
    let bg: Color
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(10)
            .frame(minWidth: 80)
            .background(bg.opacity(configuration.isPressed ? 0.7 : 1.0))
            .foregroundColor(.white)
            .cornerRadius(8)
    }
}
