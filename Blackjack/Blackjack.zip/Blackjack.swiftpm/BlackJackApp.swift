import SwiftUI

@main
struct BlackjackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
